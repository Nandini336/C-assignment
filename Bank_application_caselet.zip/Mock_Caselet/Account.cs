﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApplication
{
    public abstract class Account
    {
        public readonly long Account_Num;
        public string Username;
        public int Balance;
        public int Min_Balance = 1000;

        public Account()
        {
            this.Account_Num = genRandomnum();


        }
        public void OpenAccount() { }
        public abstract void CloseAccount();
        public abstract void EditAccount();
        public abstract void Deposit();
        public abstract void Withdraw();
        public abstract void Check_Balance();
        long genRandomnum()
        {
            long acc_num = 0;
            Random r = new Random();
            string w = "";
            int i;
            for (i = 1; i < 13; i++)
            {
                w += r.Next(0, 9).ToString();
            }
            if (w.Length == 12)
            {
                acc_num = Convert.ToInt64(w);

            }

            return acc_num;

        }

    }
}
