﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApplication
{
    public class SavingsAccount : Account,IROI,ITransaction
    {
        public int maxdeposit = 50000;
        public int mindeposit = 100;
        public int maxwithdraw = 30000;
        public int minwithdraw = 100;
        public void OpenAccount(SavingsAccount obj)
        {
            Console.WriteLine("Enter your name");
            obj.Username = Console.ReadLine();
            Console.WriteLine("Enter the amount to be deposited");
            obj.Balance = Convert.ToInt32(Console.ReadLine());
            if (obj.Balance >= Min_Balance)
            {
                Program.Slist.Add(obj);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Savings Account created successfully ");
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("Account Name:");
                Console.WriteLine(obj.Username);

                Console.Write("Account Number:");

                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine(obj.Account_Num);
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("Account Balance:{0}", obj.Balance);

            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Insufficient fund, intial balance should be more than 1000");
                Console.ForegroundColor = ConsoleColor.White;


            }

        }

        public override void CloseAccount()
        {

            Console.WriteLine("enter the account number");
            long num_check = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.Slist)
            {
                count++;
                try
                {
                    if (item.Account_Num == num_check)
                    {
                        if (item.Balance != 0)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine(" To close the Account the balance should be zero");
                            Console.WriteLine($"do you want to withdraw {item.Balance} press y");
                            string confirm;
                            Console.ForegroundColor = ConsoleColor.White;

                            confirm = Console.ReadLine().ToString();
                            if (confirm == "Y" || confirm == "y")
                            {
                                item.Balance = 0;
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine($"{item.Account_Num} deleted succesfully");
                                Program.Slist.Remove(item);
                                Console.ForegroundColor = ConsoleColor.White;

                            }

                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                throw new AccountCloseException(" To close the Account the balance should be zero");

                            }
                            break;
                        }
                    }

                    else if (count == Program.Clist.Count)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Enter the valid account number");
                        Console.ForegroundColor = ConsoleColor.White;

                    }
                }
                catch (AccountCloseException e)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(e.Message);
                    Console.ResetColor();
                }
            }
        }

        public override void EditAccount()
        {
            Console.WriteLine("enter the account number");
            long num_check = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.Slist)
            {
                count++;
                if (item.Account_Num == num_check)
                {

                    Console.WriteLine("enter the username to be modified");
                    item.Username = Console.ReadLine();
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"Username Modified to {item.Username}");
                    Console.ForegroundColor = ConsoleColor.White;

                    break;
                }
                else if (count == Program.Slist.Count)

                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("please enter the valid account number");
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
        }

        public override void Deposit()
        {
            Console.WriteLine("enter your account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.Slist)
            {
                count++;
                if (item.Account_Num == numcheck)
                {

                    Console.WriteLine($"Hi {item.Username},Please enter the amount to be deposited");
                    int deposit = Convert.ToInt32(Console.ReadLine());
                    int amount = 0;
                    amount += deposit;

                    try
                    {
                        if (amount < maxdeposit && amount > mindeposit)
                        {
                            item.Balance += amount;
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine($"Rs:{amount} deposited successfully");
                            Console.ForegroundColor = ConsoleColor.White;
                        }
                        else
                        {
                            if (amount < 100)
                            {
                                throw new MinDepositAmtException("You can not deposit ammount less than 100 ");

                            }
                            else if (amount > 50000)
                            {
                                throw new MaxDepositAmtException("You can not deposit ammount greater than 50000 ");

                            }
                        }

                    }
                    catch (MaxDepositAmtException e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    catch (MinDepositAmtException e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    break;
                }
                else if (count == Program.Clist.Count)

                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Please enter the valid account number");
                    Console.ForegroundColor = ConsoleColor.White;

                }

            }

        }

        public override void Withdraw()
        {
            Console.WriteLine("enter your account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.Slist)
            {
                count++;
                if (item.Account_Num == numcheck)
                {
                    Console.WriteLine(item.Username);
                    Console.WriteLine("enter the amount to be withdraw");
                    int withdraw = Convert.ToInt32(Console.ReadLine());

                    try
                    {
                        if (withdraw < maxwithdraw)
                        {
                            if ((item.Balance - withdraw) >= Min_Balance)
                            {
                                item.Balance -= withdraw;
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("Amount is withdrawn successfully");
                                Console.ResetColor();
                            }
                            else
                            {
                                throw new MinBalException("Insufficeient funds ! Minimum Balance after withdrawl should be greater than 1000");
                            }
                        }

                        else
                        {
                            throw new MaxwithdrawalAmount("You can not withdraw ammount greater than 50000");
                        }
                    }
                    catch (MinBalException e)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(e.Message);
                        Console.ForegroundColor = ConsoleColor.White;


                    }

                    catch (MaxwithdrawalAmount e)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(e.Message);
                        Console.ForegroundColor = ConsoleColor.White;

                    }
                    break;
                }

                else if (count == Program.Clist.Count)

                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Please entere the valid account number");
                    Console.ResetColor();
                }


            }

        }

        public override void Check_Balance()
        {
            Console.WriteLine("enter your account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.Slist)
            {
                count++;
                if (item.Account_Num == numcheck)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"hi {item.Username} your account balance is{item.Balance}");
                    Console.ForegroundColor = ConsoleColor.White;
                    GetRateOfInterest(numcheck);
                    break;
                }
                else if (count == Program.Slist.Count)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Please entere the valid account number");
                    Console.ResetColor();
                }
            }
        }

        public void getAccountDetails()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.Slist)
            {
                count++;
                if (item.Account_Num == numcheck)
                {
                    Console.WriteLine("AccountNumber:{0}", item.Account_Num);
                    Console.WriteLine("AccountName:{0}", item.Username);
                    Console.WriteLine("AccountBalance:{0}", item.Balance);
                    break;
                }
                else if (count == Program.Slist.Count)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Enter the valid account number");
                    Console.ResetColor();
                }
            }
        }
        public void TransferAmount()
        {
            long fromaccount;
            long toaccount;
            Console.WriteLine("Enter the From account number");
            fromaccount = Convert.ToInt64(Console.ReadLine());
            int count = 0; int count1 = 0;
            foreach (var item in Program.Slist)
            {
                count++;
                if (item.Account_Num== fromaccount)
                {
                    Console.WriteLine("Enter To account number");
                    toaccount = Convert.ToInt64(Console.ReadLine());


                    for (int i = 0; i < Program.Slist.Count; i++)
                    {
                        count1++;
                        if (Program.Slist[i].Account_Num == toaccount)
                        {

                            Console.WriteLine("Enter the ammount to be transfered");
                            int amount = Convert.ToInt32(Console.ReadLine());
                            if (fromaccount != toaccount)
                            {
                                if (item.Balance > amount +Min_Balance)
                                {
                                    item.Balance = item.Balance - amount;
                                    Program.Slist[i].Balance = Program.Slist[i].Balance + amount;
                                    Console.WriteLine("Balance is transferred successfully");
                                    Console.WriteLine($"The Available balance in the {Program.Slist[i].Account_Num} is {Program.Slist[i].Balance }");
                                }
                                else
                                {
                                    Console.WriteLine("Insufficient balance to transfer");
                                }

                            }
                            else
                            {
                                Console.WriteLine("Transfer can be done between two different accounts");
                            }
                            break;

                        }
                        else if (count1 == Program.Slist.Count)
                        {
                            Console.WriteLine("Please enter the valid account number");
                        }

                    }
                    break;
                }
                else if (count == Program.Slist.Count)
                {
                    Console.WriteLine("Please enter the valid account number");
                }
            }
        }

        public void GetRateOfInterest(long numcheck)
        {
            double simpleinterst = 0;
            foreach (var item in Program.Slist)
            {
                if (item.Account_Num== numcheck)
                {
                    simpleinterst = item.Balance * 0.04 * 1;
                    item.Balance = item.Balance + (int)simpleinterst;
                    Console.WriteLine($"The Available balance in {item.Account_Num} is {item.Balance}");
                }
            }
        }


    }
}

