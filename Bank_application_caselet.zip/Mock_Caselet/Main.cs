﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApplication
{
    class Program
    {
        public static List<SavingsAccount> Slist = new List<SavingsAccount>();
        public static List<CurrentAccount> Clist = new List<CurrentAccount>();

        static void Main(string[] args)
        {

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("-----------------------------------------------");
            Console.BackgroundColor = ConsoleColor.Cyan;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("<<<<<<< WELCOME TO THE BANKING SERVICES >>>>>>>");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("-----------------------------------------------");
            string Confirm;
            do
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("1. SavingAccount \n2. CurrentAccount");
                Console.ForegroundColor = ConsoleColor.White;

                int choice = GetInt("Enter your choice");


                switch (choice)
                {
                    case 1:
                        displayMenu();
                        SavingsAccount sa = new SavingsAccount();
                        accountOptions(sa);
                        break;

                    case 2:
                        displayMenu();
                        CurrentAccount ca = new CurrentAccount();
                        accountOptions(ca);
                        break;

                    default:
                        Console.WriteLine("Please choose a valid option");
                        break;
                }
                Console.BackgroundColor = ConsoleColor.DarkGray;
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("Enter 'y' to continue");
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.White;
                Confirm = Console.ReadLine().ToUpper();
            } while (Confirm == "Y");


        }

        private static int GetInt(string message)
        {
            int val = 0;
            while (true)
            {

                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                    break;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("The entered number is not in correct format please try again");
                Console.ResetColor();
            }
            return val;
        }

        public static void displayMenu()
        {
            Console.BackgroundColor = ConsoleColor.Yellow;

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("______MENU______");
            Console.ForegroundColor = ConsoleColor.White;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("1.Open an account");
            Console.WriteLine("2.Edit Account");
            Console.WriteLine("3.Deposit");
            Console.WriteLine("4.Withdrawal");
            Console.WriteLine("5.Check Balance");
            Console.WriteLine("6.CloseAccount");
            Console.WriteLine("7.GetDetails");

        }

        public static void accountOptions(SavingsAccount obj)
        {
            int choice = GetInt("Enter the choice");
            switch (choice)
            {
                case 1:
                    obj.OpenAccount(obj);
                    break;
                case 2:
                    obj.EditAccount();
                    break;
                case 3:
                    obj.Deposit();
                    break;
                case 4:
                    obj.Withdraw();
                    break;
                case 5:
                    obj.Check_Balance();
                    break;
                case 6:
                    obj.CloseAccount();
                    break;
                default:
                    Console.WriteLine("Please choose a valid option");
                    break;
            }
        }

        public static void accountOptions(CurrentAccount obj)
        {
            int choice = GetInt("Enter the choice");
            switch (choice)
            {
                case 1:
                    obj.createAccount(obj);
                    break;
                case 2:
                    obj.EditAccount();
                    break;
                case 3:
                    obj.Deposit();
                    break;
                case 4:
                    obj.Withdraw();
                    break;
                case 5:
                    obj.Check_Balance();
                    break;
                case 6:
                    obj.CloseAccount();
                    break;
                default:
                    Console.WriteLine("Please choose a valid option");
                    break;
            }
        }
    }
}
