﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercise13
{
    class DateTime
    {
        static void Main(string[] args)
        {

            string given = givendate();
            Console.WriteLine(given);
            string today = currentdate(); //Console.WriteLine(total);
            TimeSpan sub = subtracts(given, today);

            double hours = sub.Hours + (sub.Days * 24);
            string time = string.Format("{0} hours & {1} minutes", hours, sub.Minutes);

            double totalminutes = (sub).TotalMinutes;
            Console.WriteLine($"total minutes={totalminutes}");
            double days = sub.TotalDays;
            Console.WriteLine($"total days={days}");
            Console.ReadLine();

        }
        private static string givendate()
        {
            System.DateTime date = new System.DateTime(1945, 8, 15, 14, 30, 0);
            return date.ToString();
        }
        private static string currentdate()
        {

            System.Console.WriteLine(System.DateTime.Today.ToString());

            return System.DateTime.Now.ToString();
        }
        private static TimeSpan subtracts(string s1, string s2)
        {

            System.DateTime gDate = Convert.ToDateTime(s1);
            System.DateTime cDate = Convert.ToDateTime(s2);
            TimeSpan span = gDate.Subtract(cDate);
            return span;


        }
    }
}



