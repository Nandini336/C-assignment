﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delegatefunc
{
    class Program
    {
        // delegate string Mydelegate(string m);
        delegate int Mydelegate(int i);
        static void Main(string[] args)
        {
            int m = 5;
            Mydelegate del = null;
            del += (i) =>
            {
                Console.WriteLine(i);
                return i;
            };

            del += display;
            del(m);

           // Func<in T,out T> delegatefuntion = 

            //del("Hi harika this is delegate without using the func keyword");


            // Func<string, string> delegatefunc = details;
            //string delvar= delegatefunc("Hi harika This is delegate function");
            // Console.WriteLine(delvar);
            Console.ReadLine();
        }


        private static string details(string message)
        {

            Console.WriteLine(message);
            return message;
        }

        private static int display(int i)
        {
            Console.WriteLine(i);
            return i;

        }
    }
}
