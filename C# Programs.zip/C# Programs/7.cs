﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Statisticoperations
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0; int median = 0;
            Console.WriteLine("enter size");
            int sizeofarray = Convert.ToInt32(Console.ReadLine());
            int[] array = new int[sizeofarray];
            Console.WriteLine("enter numbers in to the array");
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("display");
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i]);
            }

            Console.WriteLine("mean of array");
            for (int i = 0; i < array.Length; i++)
            {

                sum = sum + array[i];
            }
            int mean = sum / (array.Length);
            Console.WriteLine("The mean of the array numbers is",mean);

            Console.WriteLine("median of array Numbers");
            Array.Sort(array); // function provide us sort the array

            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i]);
            }
            
            if (array.Length % 2 == 0)
            {
                median = (array[array.Length / 2] + array[((array.Length - 1) / 2)]);
            }
            else
                 {
                median = array[(array.Length) / 2];
             }
            Console.WriteLine($"median={median}");
            Console.WriteLine("Standard deviation");
            double sumOfnumbers = 0;
            for (int i = 0; i < array.Length; i++)
            {
                sumOfnumbers += (array[i] - mean) * (array[i] - mean);
            }
            double standarddeviation = Math.Sqrt(sumOfnumbers / array.Length);//Predefined function provide us to find the squareroot directly
            Console.WriteLine($"standard deviation={standarddeviation}");
            Console.WriteLine("mode of array numbers");
            int maxvalue = 0;
            int maxcount = 0;
            for (int i = 0; i < array.Length; i++)
            {
                int count = 0;
                for (int j = 0; j < array.Length; j++)
                {
                    if (array[i] == array[j])
                    {
                        count++;
                    }
                    if (count > maxcount)
                    {
                        maxcount = count;
                        maxvalue = array[i];
                    }
                }
            }
            Console.WriteLine("mode of numbers" + maxvalue);
            Console.ReadLine();
        }
    }
}


