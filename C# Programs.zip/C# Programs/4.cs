﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FibonacciSeries
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = GetInt("Enter the number");
            int first = 0;
            int second = 1;
            int sum = 0;
            int count;
            Console.WriteLine("The fibonacci series of {0}",num);
            Console.WriteLine(first);
            Console.WriteLine(second);
            for (count = 1; count <= num-2; count++)
            {
                sum = first + second;
                first = second;
                second = sum;
                Console.WriteLine(sum);
            }
            Console.ReadLine();
        }

        private static int GetInt(string message)
        {
            int val = 0;
            while (true)
            {

                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                    break;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Number is not in correct format please try again");
            }
            return val;
        }
    }
}
