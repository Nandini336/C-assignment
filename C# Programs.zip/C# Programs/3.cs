﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberOfdigits
{
    class Program
    {
        static void Main(string[] args)
        {

            int num = GetInt("Enter the number");
            int i = num;
            int sum = 0;
            while (num > 0)
            {
                int rem = num % 10;
                sum = sum + rem;
                num = num / 10;

            }
            Console.WriteLine("The sum of the digits of the number {0} is {1} ", i, sum);
            Console.ReadLine();
        }

        /*To get the input from the user
           Error handling to ensure user enters an integer
           incase other value give a chance to try again
        */
        private static int GetInt(string message)
        {
            int val = 0;
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                    break;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Number is not in the correct format Please try agian");
            }
            return val;
        }
        
    }
}
