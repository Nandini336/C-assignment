﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pascals_triangle
{
    class Pascals
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Pascal Triangle Program");
            System.Console.WriteLine("Enter the number of rows:");
            int n = Convert.ToInt32(Console.ReadLine());
            for (int y = 0; y < n; y++)
            {
                int c = 1;
                for (int q = 0; q < n - y; q++)
                {
                    System.Console.WriteLine(" ");
                }
                for (int x = 0; x <= y; x++)
                {
                    System.Console.Write(" {0:D} ", c);
                    c = c * (y - x) / (x + 1);
                }
                System.Console.WriteLine();
               
            }
            System.Console.ReadLine();
        }
    }
}

