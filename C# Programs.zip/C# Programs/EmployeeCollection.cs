﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeCollection
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> emps = new List<Employee>
            {
                new Employee { ID =getId("Enter the ID"),name = getName("Enter the name of the Employee"),
                    email = getEmail("Enter the email") },
                new Employee { ID =getId("Enter the ID"),name = getName("Enter the name of the Employee"),
                    email = getEmail("Enter the email") },
                new Employee { ID =getId("Enter the ID"),name = getName("Enter the name of the Employee"),
                    email = getEmail("Enter the email") },
            };
            Console.Clear();
            foreach (var item in emps)
            {
                Console.WriteLine("The employee Id is {0} and name is {1} and emailid is" + item.ID, item.ID, item.email);
                Console.ReadLine();
            }

            foreach (var item in emps)
            {
                var result = item.name.Contains(Console.ReadLine());
                Console.WriteLine(result);
            }

            

        }




            private static string getName(string message)
            {
                Console.WriteLine(message);
                return Console.ReadLine();
            }

            private static string getEmail(string message)
            {
                Console.WriteLine(message);
                return Console.ReadLine();
            }

            public static int  getId(string message)
            {
                     Console.WriteLine(message);
                return Convert.ToInt32(Console.ReadLine());
             }


            }
    }


    class Employee
    {
        public int ID;
        public string name;
        public string email;

    }



