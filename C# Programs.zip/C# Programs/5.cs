﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Currency
{
    class Program
    {
        static void Main(string[] args)
        {
            float currency, Rvalue, Bvalue, rupees, pounds;
            currency = GetInt("Enter the currency of dollars");
            Rvalue = GetInt("Enter the Rupees equivalent to one dollar");
            Bvalue = GetInt("Enter the British pounds equivalent to one dollar");
            rupees = currency * Rvalue;
            pounds = currency * Bvalue;
            Console.WriteLine("The dollar currency {0} in the eqivalent Indian Rupees is {1}", currency, rupees);
            Console.WriteLine("The dollar currency {0} in the eqivalent British Pounds is {1}", currency, pounds);
            Console.ReadLine();
        }

        private static int GetInt(string message)
        {
            int val = 0;
            while (true)
            {

                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                    break;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Number is not in correct format please try again");
            }
            return val;
        }
    }
}
