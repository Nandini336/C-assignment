﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Primenum
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = GetInt("Enter the number");
            int i = num;
            bool result = IsPrimeNumber(i);
            if (result == false)
            {
                Console.WriteLine("The given number {0} is not a prime number" ,num);
               
            }
            else
            {
                Console.WriteLine("The given number {0} is  a  prime number",num);
            }
            Console.ReadLine();
        }

        private static int GetInt(string message)
        {
            int val = 0;
            while (true)
            {

                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                    break;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Number is not in correct format please try again");
            }
            return val;
        }


        private static bool IsPrimeNumber(int num) {
            int i;
            for (i = 2;i <num/2;i++)
            {
                if (num % i == 0)
                {
                    return false;
                }

            }
            return true;
        }
    }

}
