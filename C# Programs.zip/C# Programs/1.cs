﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class ReversingNumber
    {
        static void Main(string[] args)
        {
           
            int reverse = 0;
            int num = GetInt("Enter the number to be reversed");
            int i = num;
            while (i > 0)
            {
                int rem = i % 10;
                reverse = rem + (reverse * 10);
                i = i / 10;
            }
            Console.WriteLine("The reverse of the {0} number is {1} " ,num, reverse);
            Console.ReadLine();

        }

        private static int GetInt(string message)
        {
            int val = 0;
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                    break;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("The entered number is not in correct format please try again");
            }
            return val;
        }
    }
}



// Number is in correct format also it is  always entering into the catch block even I give condition for catch block
//         while (true)
//           {
//               Console.WriteLine("Enter the number to be reversed");

//               try
//                {
//                    Console.ForegroundColor = ConsoleColor.White;
//                    num = Convert.ToInt32(Console.ReadLine());
//                    while (num > 0)
//                    {
//                        int rem = num % 10;
//                        reverse = rem + (reverse* 10);
//                        num = num / 10;
//                    }

//                    Console.WriteLine("THe reverse of the {0} is {1}" + num, reverse);
//                    Console.ReadLine();

//                }
//                catch (Exception e) when(Convert.ToString(num) == " " || Convert.ToString(num) >= "A" )
//                {
//                    Console.ForegroundColor = ConsoleColor.Red;
//                    Console.WriteLine("Error occured  please  enter the number again" );

//                }
//          }