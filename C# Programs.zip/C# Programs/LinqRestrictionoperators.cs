﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqRestrictioOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             First where restriction operator
             */


            Console.WriteLine("Enter the size of the employee list");
            int sizeoflist = Convert.ToInt32(Console.ReadLine());
            List < Employee > list= new List<Employee>(sizeoflist);
            for (int i = 0; i < sizeoflist; i++)
            {
                Employee e = new Employee { id = details("Enter the id of the employee"),
                    name = details("Enter the name of the employee") };
                list.Add(e);

            }
            records(list);



        }

        static void records(List<Employee> list)
        {
            // int[] numbers = { 1, 2, 3, 4, 5, 6,7, 8, 9 };
            //var lownums = from i in numbers
            //              where i < 5
            //              select i;

            //var lownums = from i in numbers
            //              where i != 5
            //              select i;

            //var lownums = from i in numbers
            //              where i != 5 && i != 67
            //              select i;

            //var lownums = from i in list
            //              where i.name != "harika"
            //              select i;
            
            Console.WriteLine("The numbers below the 5 are");
            foreach (var item in lownums)
            {
                Console.WriteLine(item.name);
                Console.ReadLine();
            }
        }


        //
        public static string details(string message)
        {
            Console.WriteLine(message);
            return Console.ReadLine();

        }

    }

  public   class Employee
    {
        public string id;
        public string name;

    }
}
