﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace factorial
{
    class Program
    {
        static void Main(string[] args)
        {
            int factorial;
             int num = GetInt("Enter the number to find the factorial");
            int i = num;
            while (i > 0)
            {

                factorial = 1;
                num = i;
                while (num > 0)
                {
                    factorial = factorial * num;
                    num--;
                }
                Console.WriteLine("The factorial of {0} is {1}", i, factorial);
                 i--;
              }
        Console.ReadLine();
        }

        /*To get the inpput from the user
         * To ensure that the use enters the integer avalue only
         * in case of ohter value give user other chance to enter again
         */

        private static int GetInt(string message)
        {
            int val = 0;
            while (true)
            {
                
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                    break;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Number is not in correct format please try again");
            }
            return val;
        }
      
    }
}
