﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptionhandling
{
    class ExceptionTest
    {
        static double SafeDivision(double x, double y)
        {
            if (x == 0 && y == 0)
                throw new Exception();
            if (y == 0)
                throw new System.DivideByZeroException();
            return x / y;
        }
        static void Main()
        {
            // Input for test purposes. Change the values to see
            // exception handling behavior.
            double a = 0, b = 0;
            double result = 0;

            try
            {
                result = SafeDivision(a, b);
                Console.WriteLine("{0} divided by {1} = {2}", a, b, result);
                Console.ReadLine();
            }
            catch (DivideByZeroException e)
            {
                Console.WriteLine("Attempted divide by zero.");
                Console.ReadLine();
            }
            catch (Exception e)
            {
                Console.WriteLine("Both the numbers are zero" + e.Message);
                Console.ReadLine();

            }
        }
    }
}
